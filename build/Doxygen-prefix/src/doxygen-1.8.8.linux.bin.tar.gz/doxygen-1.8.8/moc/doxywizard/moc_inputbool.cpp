/****************************************************************************
** Meta object code from reading C++ file 'inputbool.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../addon/doxywizard/inputbool.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'inputbool.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_InputBool[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x05,
      23,   21,   10,   10, 0x05,
      44,   10,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
      61,   10,   10,   10, 0x0a,
      69,   10,   10,   10, 0x0a,
      84,   10,   10,   10, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_InputBool[] = {
    "InputBool\0\0changed()\0,\0toggle(QString,bool)\0"
    "showHelp(Input*)\0reset()\0setValue(bool)\0"
    "help()\0"
};

void InputBool::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        InputBool *_t = static_cast<InputBool *>(_o);
        switch (_id) {
        case 0: _t->changed(); break;
        case 1: _t->toggle((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 2: _t->showHelp((*reinterpret_cast< Input*(*)>(_a[1]))); break;
        case 3: _t->reset(); break;
        case 4: _t->setValue((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->help(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData InputBool::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject InputBool::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_InputBool,
      qt_meta_data_InputBool, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &InputBool::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *InputBool::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *InputBool::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_InputBool))
        return static_cast<void*>(const_cast< InputBool*>(this));
    if (!strcmp(_clname, "Input"))
        return static_cast< Input*>(const_cast< InputBool*>(this));
    return QObject::qt_metacast(_clname);
}

int InputBool::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void InputBool::changed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void InputBool::toggle(QString _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void InputBool::showHelp(Input * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
